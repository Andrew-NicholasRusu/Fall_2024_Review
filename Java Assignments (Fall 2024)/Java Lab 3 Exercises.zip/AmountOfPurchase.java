/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package amount.of.purchase;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class AmountOfPurchase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    double purchaseamount,statesalestax,countysalestax,totalsalestax,totalofthesale;
      Scanner keyboard=new Scanner(System.in);
      System.out.println("What is the total amount of your purchase?");
      purchaseamount=keyboard.nextDouble();
      statesalestax=purchaseamount*0.055;
      countysalestax=purchaseamount*0.02;
    System.out.println("statesalestax" +statesalestax);
    System.out.println("countrysalestax" +countysalestax);
    totalsalestax=statesalestax+countysalestax;
    System.out.println("totalsalestax" +totalsalestax);
    totalofthesale=purchaseamount+totalsalestax;
    System.out.println("totalofthesale" +totalofthesale);
    }
    }
    

