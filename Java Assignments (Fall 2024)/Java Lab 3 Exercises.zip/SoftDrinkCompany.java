/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package soft.drink.company;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class SoftDrinkCompany {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double Totalcustomers,Oneormoreenergydrinks,Prefercitrus;  
        Scanner keyboard=new Scanner(System.in);
        Totalcustomers=15000;
    System.out.println("Totalcustomers" +Totalcustomers);
    Oneormoreenergydrinks=Totalcustomers*0.18;
    System.out.println("Oneormoreenergydrinks" +Oneormoreenergydrinks);
    Prefercitrus=Totalcustomers*0.58;
    System.out.println("Prefercitrus" +Prefercitrus);
    }
    
}
