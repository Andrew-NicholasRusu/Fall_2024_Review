/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bankaccount;

import java.util.Scanner;
/**
 *
 * @author User
 */
public class BankAccount {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
    // A=amountofmoneyafternumberofyears
    // p=principalmountthatwasoriginallydepositedintotheaccount
    // r=annual interest rate
    // n=numberoftimesperyearthattheinterestiscompounded
    // t=specifiednumberofyears
    
    Scanner keyboard=new Scanner(System.in);
    
    System.out.println("What is the amount of principal originally deposited into your account?");
    float moneyAfterYears;
    moneyAfterYears = keyboard.nextFloat();
    
    System.out.println("What is the annual interest rate paid by account?");
    float annualRate;
    annualRate = keyboard.nextFloat();
    
    System.out.println("What is the number of times per year that the interest is compounded?");
    double interestCompounded;
    interestCompounded = keyboard.nextDouble()/100;
    
    System.out.println("What is the number of years the account will left to earn interest?");
    float yearsLeftToEarnInterest;
    yearsLeftToEarnInterest = keyboard.nextFloat();
    
    // A=p(1+r/n)^nt
    
    double total = moneyAfterYears*Math.pow(1+(annualRate/interestCompounded), interestCompounded*yearsLeftToEarnInterest);
    System.out.println("total"+total);
    
    //xilef992
    //Felix Allard
    }
    
}
