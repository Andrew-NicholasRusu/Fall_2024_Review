/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package favorite.city;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class FavoriteCity {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        
        //String name = "Joe Mahoney";
        //String value = new String ("Hello");
        String favoriteCity;
        Scanner sc = new Scanner(System.in);
        System.out.println("What is your favorite city?");
        favoriteCity=sc.nextLine();
        System.out.println(favoriteCity.length());
        System.out.println(favoriteCity.toUpperCase());
        System.out.println(favoriteCity.toLowerCase());
        System.out.println(favoriteCity.charAt(0));        
        
    }
    
}
