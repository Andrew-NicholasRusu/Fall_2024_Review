/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package miletokilometer;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class MiletoKilometer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     double Miles, Kilometers;
     Scanner sc = new Scanner(System.in);
     System.out.println("Enter the number of miles you conquered.");
     Miles=sc.nextDouble();
     double converter=1.6;
     Kilometers=Miles*converter;
     System.out.println("Kilometers" +Kilometers);
     System.out.printf("#of Miles %.2f, The number of kilometers are %8.2f", Miles, Kilometers);
         
    }
    
}
