/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package magicdate;
import java.util.Scanner;

public class MagicDateDemo {
       
    public static void main(String[] args) {
        Scanner keyboard=new Scanner(System.in);
        Integer month, year, day;
        MagicDate date = new MagicDate(0,0,0);
        System.out.println("Enter the special month.");
        month = keyboard.nextInt();
        date.setmonth(month);
        System.out.println("Enter the special day.");
        day = keyboard.nextInt();
        date.setday(day);
        System.out.println("Enter the special year that has two digits.");
        year = keyboard.nextInt();
        date.setmonth(year);
        
        System.out.println(date.isMagic(year,month,day));
        
    }
    
}
