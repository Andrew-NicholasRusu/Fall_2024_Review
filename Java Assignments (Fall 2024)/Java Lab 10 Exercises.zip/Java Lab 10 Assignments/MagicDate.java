/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package magicdate;

public class MagicDate {
private Integer year;
private Integer month;
private Integer day;
    public MagicDate(Integer y, Integer m, Integer d){
    year = y;
    month = m;
    day = d;
}
public void setyear(Integer y){
    year = y;
}
public Integer getyear(){
    return year;
}    
public void setmonth(Integer m){
    month = m;
}
public Integer getmonth(){
    return month;
}
public void setday(Integer d){
    day = d;
}
public Integer getday(){
    return day;
}
public String isMagic(Integer year,Integer month,Integer day){
if (day == 10 && month == 6 && year == 1960){
  return "The day is magic.";
}
else {    
   return "The day is sadly not magic.";
}
}
}
