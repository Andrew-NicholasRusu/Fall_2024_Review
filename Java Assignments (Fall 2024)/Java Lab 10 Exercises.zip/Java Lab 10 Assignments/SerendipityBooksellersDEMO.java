/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package serendipity.booksellersdemo;
import java.util.Scanner;

public class SerendipityBooksellersDEMO {

    public static void main(String[] args) {
    int books, points;    
        
        Scanner keyboard=new Scanner(System.in);
        
        System.out.println("How many books did you purchase this month?");
    books = keyboard.nextInt();
    
    if (books == 0){
        points = 0;
      System.out.println("Your number of points are " +points);
    } 
    else if(books == 1){
              points = 5;
      System.out.println("Your number of points are " +points);        
    }
    
    else if(books == 2){
        points = 15;
      System.out.println("Your number of points are " +points);
    }
    
    else if(books == 3){
        points = 30;
      System.out.println("Your number of points are " +points);
    }
    
    else if(books == +4){
        points = 60;
      System.out.println("Your number of points are " +points);
    }
    
    }
}
