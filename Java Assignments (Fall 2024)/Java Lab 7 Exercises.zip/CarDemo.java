/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package car;

public class CarDemo {
public static void main(String[]args) {
    
    Car myCar = new Car(2024,"BMW");
    
    System.out.println("Speed before accelaration = " + myCar.getspeed());
    
    myCar.accelerate();
    myCar.accelerate();
    myCar.accelerate();
    myCar.accelerate();
    myCar.accelerate();
    
    System.out.println("Speed after accelaration = " + myCar.getspeed());
    
    myCar.brake();
    myCar.brake();
    myCar.brake();
    myCar.brake();
    myCar.brake();
    
    System.out.println("Speed after brake = "+myCar.getspeed());
            
}
    
}
