/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package temperature;
import java.util.Scanner;

public class TemperatureDemo {
public static void main(String[]args) {
Scanner keyboard=new Scanner(System.in);
    
  double ftemp;
    System.out.println("Please give an amount of degress fahrenheit.");
    
    ftemp=keyboard.nextDouble();
    
    Temperature myTemp=new Temperature(ftemp);
    
    System.out.println("The temperature in fahrenheit is "+myTemp.getFahrenheit()); 
    
    System.out.println("The temperature in celsius is "+myTemp.getCelsius(ftemp));
    
    System.out.println("The temperature in kelvin is "+myTemp.getKelvin());
}
}