/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package car;

public class Car {
    
    private int yearModel;
    private String make;
    private int speed;


    public Car(int yM, String mk) {
        yearModel=yM;
        make=mk;
        speed=0;        
    }
    public void setyearModel(int yM){   
        yearModel=yM;
    }
    
    public int getyearModel(){
        return yearModel;
    }
    
    public void setmake(String mk){
        make=mk;
    }
    
    public String make(){
        return make;
    }
    
    public void setspeed(){
    }
    
    public int getspeed(){
        return speed;
    }
    
    public void accelerate(){
        speed+=5;
    }
    public void brake(){
        speed-=5;
    }
    
    }
    
    

