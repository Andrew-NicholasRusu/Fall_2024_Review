/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package temperature;

public class Temperature {
    
    private double ftemp;
    private double newtemp;
    public Temperature(double ft) {
        ftemp=ft;       
    }
    public void setFahrenheit (double ft){
        ftemp=ft;
    }
    public double getFahrenheit (){
        return ftemp;
    }

    /**
     *
     * @return
     */
    public double getCelsius (double ftemp){
        newtemp = ((5.0/9) * (ftemp - 32));
        return newtemp;
    }
    public double getKelvin (){
        return ((5.0/9) * (ftemp - 32)) + 273;
    }    
}
