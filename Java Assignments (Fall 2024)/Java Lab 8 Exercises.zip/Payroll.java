/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package payroll;

public class Payroll {
    
    private String employeeName;
    private int idNumber;
    private double hourlyPayRate;
    private double hoursWorked;

public Payroll (String eM, double hPR, int idN, double hW){
    employeeName = eM;
    hourlyPayRate = hPR;
    idNumber = idN;
    hoursWorked = hW;
}
public void setemployeeName(String eM){
    employeeName = eM;
}
public String getemployeeName(){
    return employeeName;
}
public void setidNumber(int idN){
    idNumber = idN;
}
public int getidNumber(){
    return idNumber;
}
public void sethourlyPayRate(double hPR){
    hourlyPayRate = hPR;
}
public double gethourlyPayRate(){
    return hourlyPayRate;
}
public void sethoursWorked(double hW){
    hoursWorked = hW;
}
public double gethoursWorked(){
    return hoursWorked;
}
public double getgrosspPay(){
    return hourlyPayRate * hoursWorked;
}
}
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    

