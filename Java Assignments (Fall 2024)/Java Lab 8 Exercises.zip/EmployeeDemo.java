/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package payroll;
import java.util.Scanner;

public class EmployeeDemo {
public static void main(String[]args) { 
Scanner keyboard=new Scanner(System.in);
String eM;
int idN;
double hPR, hW;



System.out.println("Please give the employee's name");
eM = keyboard.nextLine();

System.out.println("Please give the employee's idNumber");
idN = keyboard.nextInt();

System.out.println("Please give the employee's hours worked");
hW = keyboard.nextDouble();

System.out.println("Please give the employee's hourly rate");
hPR = keyboard.nextDouble();

Payroll emp1=new Payroll(eM, hPR, idN, hW);

System.out.println("The employee's name is " +emp1.getemployeeName());
System.out.println("The ID number of the employee is " +emp1.getidNumber());
System.out.println("The hours this employee works daily is " +emp1.gethoursWorked());
System.out.println("The employee's hourly rate is " +emp1.gethourlyPayRate());
System.out.println("The gross pay of the employee is "+emp1.getgrosspPay());

}


    
    
    }
    
