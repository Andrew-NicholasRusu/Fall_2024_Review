/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package circle;

public class Circle {

    private double radius;
    
    private final double pi = 3.14159;

    // first constructor
    public Circle(){
        radius = 1;
    }
    
    
    // second constructor
    public Circle(double rad) {
       radius = rad; 
    }

    
    
    public void setRadius(double rad){
        radius = rad;
    }

    public double getRadius (){
        return radius;
    }

    public double getArea (){
        return pi*Math.pow(radius, 2);
    }

    public double getDiameter (){
        return 2*radius;
    }

    public double getCircumference (){
        return 2*pi*radius;
    }

}
