/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package circle;
import java.util.Scanner;

public class CircleDemo {
    
public static void main(String[]args) {
    
Scanner keyboard=new Scanner(System.in);

    double radius;
    
    
    // calling the first constructor.
    Circle cir1 = new Circle();
    System.out.println("Please input the first radius:");    
    radius=keyboard.nextDouble();
    cir1.setRadius(radius);
    System.out.println("First radius = "+cir1.getRadius());
    System.out.println("First area = "+cir1.getArea());
    System.out.println("First diameter = "+cir1.getDiameter());
    System.out.println("First circumference = "+cir1.getCircumference());
    
    System.out.println("");
    
  
    System.out.println("Please input the second radius:");
    radius=keyboard.nextDouble();
    
    // calling the second constructor.
    Circle rad2 = new Circle(radius);
    
    System.out.println("Second radius = "+rad2.getRadius());
    System.out.println("Second area = "+rad2.getArea());
    System.out.println("Second diameter = "+rad2.getDiameter());
    System.out.println("Second circumference = "+rad2.getCircumference());
}   
}
