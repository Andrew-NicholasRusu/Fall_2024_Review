/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package employee;

public class Employee {

    private String name;
    private int IDNumber;
    private String department;
    private String position;
   
    public void setname(String n){
        name=n;
    }
    
    public void setIDNumber(int ID){
        IDNumber=ID;
    }
    
    public void setdepartment(String d){
        department=d;
    }
    
    public void setposition(String p){
        position=p;
    }
    
    
    public String getname(){
    return name;
    }
    public int getIDNumber(){
        return IDNumber;
    }
    public String getdepartment(){
        return department;
    }
    public String getposition(){
        return position;
    }
    
    
}