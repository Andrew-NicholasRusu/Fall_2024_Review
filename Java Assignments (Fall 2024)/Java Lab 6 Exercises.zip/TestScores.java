/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testscores;

public class TestScores {
    
    private double test1;
    private double test2;
    private double test3;
    

    public void setTest1(double t1){
        test1 = t1;
    }
    
    public void setTest2(double t2){
        test2 = t2;
    }
    
    public void setTest3(double t3){
        test3 = t3;
    }
    
    /**
     *
     * @return
     */
    public double gettest1(){
        return test1;
    }
    public double gettest2(){
        return test2;
    }
    public double gettest3(){
        return test3;
           
    }
    public double getaverage(){
        return (test1 + test2 + test3)/3;
    }
}
