/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testscores;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class testScoreDemo {


    public static void main(String[]args) {
    Scanner keyboard=new Scanner(System.in);
       double test1, test2, test3; 
        TestScores student1=new TestScores();
        
        
    System.out.println("Please give the mark of the first test.");
    test1=keyboard.nextDouble();
    student1.setTest1(test1);
    System.out.println("Mark of Test 1 = " +student1.gettest1());
    
    System.out.println("Please give the mark of the second test.");
    test2=keyboard.nextDouble();
    student1.setTest2(test2);
    System.out.println("Mark of test 2 = "+student1.gettest2());
    
    System.out.println("Please give the mark of the third test.");
    test3=keyboard.nextDouble();
    student1.setTest3(test3);
    System.out.println("Mark of Test 3 = "+student1.gettest3());    
    
    
    System.out.println("The total average is "+student1.getaverage());
    }

}
