/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employee;

/**
 *
 * @author User
 */
public class EmployeeDemo {
    
    public static void main(String[] args){
    Employee e1=new Employee();
        e1.setname("Susan Meyers");
        e1.setIDNumber(47899);
        e1.setdepartment("Accounting");
        e1.setposition("Vice President");
        
    Employee e2=new Employee();
        e2.setname("Mark Jones");
        e2.setIDNumber(39119);
        e2.setdepartment("IT");
        e2.setposition("Programmer");
        
    Employee e3=new Employee();
        e3.setname("Joy Rogers");
        e3.setIDNumber(81774);
        e3.setdepartment("Manufacturing");
        e3.setposition("Engineer");
    
    System.out.println("Employee #1 is " +e1.getname()+ "."
            + "\n"+e1.getname()+ "' IDNumber is " +e1.getIDNumber()+"."
            + "\n"+e1.getname()+ "' department is " +e1.getdepartment()+ "."
            + "\n"+e1.getname()+ "' postion is " +e1.getposition()+".");
            
    System.out.println();
    System.out.println("Employee #2 is "+e2.getname()+"."
            + "\n"+e2.getname()+ "' IDNumber is " +e2.getIDNumber()+"."
            + "\n"+e2.getname()+ "' department is " +e2.getdepartment()+ "."
            + "\n"+e2.getname()+ "' postion is " +e2.getposition()+ ".");
    System.out.println();
    System.out.println("Employee #3 is "+e3.getname()+"."
            + "\n"+e3.getname()+ "' IDNumber is " +e3.getIDNumber()+"."
            + "\n"+e3.getname()+ "' department is " +e3.getdepartment()+ "."
            + "\n"+e3.getname()+ "' postion is " +e3.getposition()+ ".");
           }
}
