/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package acmesoftwareinc;

/**
 *
 * @author User
 */
public class AcmeSoftwareInc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //         Last Month (Purchasing)
        // Number of shares Joe purchased = 1000
        // It costs $32.87 per share
        // Joe paid his stockbroker a commission that amounted to 2% of the amount he paid for the stock.
        
        //         Two Weeks Later (Sold the Shares)
        // The number of shares that Joe sold was 1,000.
        // He sold the stock for $33.92 per share.
        // He paid his stockbroker another commission that amounted to 2% of the amount he received for the stock.
    Double Moneypaidforstock, Moneysoldforstock, Commissionfrompaying, Commissionfromreceiving,Totalpaid, Totalrecieved, Maxprofit;
    Moneypaidforstock = 1000*32.87;
    System.out.println("moneypaidforstock = $" +Moneypaidforstock);
    Commissionfrompaying = (32.87/100)*(2)*(1000);
    System.out.println("Commissionfrompaying = $" +Commissionfrompaying);
    Totalpaid = Moneypaidforstock+Commissionfrompaying;
    System.out.println("Totalpaid = $" +Totalpaid);
    Moneysoldforstock = 1000*33.92;
    System.out.println("Moneysoldforstock = $" +Moneysoldforstock);
    Commissionfromreceiving = (33.92/100)*(2)*(1000);
    System.out.println("Commissionfromreceiving = $" +Commissionfromreceiving);
    Totalrecieved = Moneysoldforstock-Commissionfromreceiving;
    System.out.println("Totalrecieved = $" +Totalrecieved);
    Maxprofit=Totalrecieved-Totalpaid;
    System.out.println("Maxprofit = $" + Maxprofit);
    
    System.out.println();
    
    System.out.println();
                  
    
    System.out.printf("Joe paid $" +Moneypaidforstock+ " for the stock."
            + "\nJoe paid his broker a commission of $" +Commissionfrompaying+ " on the purchase."
            + "\nSo, Joe paid a total of $" +Totalpaid+ "."
            + "\nJoe sold the stock for $" +Moneysoldforstock+ "."
            + "\nJoe paid his broker a commission of $" +-Commissionfromreceiving+ " on the sale."
            + "\nSo, Joe recieved a total of $" +Totalrecieved+ "."
            + "\nJoe's profit or loss: " + Maxprofit+ ".");
    System.out.println();
    
    }
    
}
