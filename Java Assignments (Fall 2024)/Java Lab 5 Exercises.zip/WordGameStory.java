/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package wordgame.story;

import java.util.Scanner;
/**
 *
 * @author User
 */
public class WordGameStory {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    String name,age,city,college,profession,typeofanimal, animalname;
    Scanner keyboard=new Scanner(System.in);
        System.out.println("What is your name?");
        name=keyboard.nextLine();
        System.out.println("name= " +name);
        System.out.println("What age you started College/University?");
        age=keyboard.nextLine();
        System.out.println("age= " +age);
        System.out.println("Which City are you located in?");
        city=keyboard.nextLine();
        System.out.println("city= " +city);
        System.out.println("Which College did you attend after High School?");
        college=keyboard.nextLine();
        System.out.println("college= " +college);
        System.out.println("What do you want to be when you finish College?");
        profession=keyboard.nextLine();
        System.out.println("profession= " +profession);
        System.out.println("What type of animal do you wish to adopt?");
        typeofanimal=keyboard.nextLine();
        System.out.println("typeofanimal= " +typeofanimal);
        System.out.println("What is the name of your pet?");
        animalname=keyboard.nextLine();
        System.out.println("animalname= " +animalname); 
        System.out.println("");
    System.out.printf("There was once a person named " + name + " who lived in " + city + ". "
            + "At the age of " + age + ", " + name + " went to college at " + college + ""
                   + ".\n " + name + " graduated and went to work as an " + profession + "."
                           + " Then, " + name + " adopted a " + typeofanimal + " named " + animalname + "."
                                   + " They both lived happily ever after! \n");
        System.out.println("");                            
    
    }
    
}
