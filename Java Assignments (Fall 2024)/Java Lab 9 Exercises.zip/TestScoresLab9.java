
package testscores.lab.pkg9;

public class TestScoresLab9 {

    private double test1;
    private double test2;
    private double test3;
    
     public TestScoresLab9(double t1,double t2,double t3){
        
        test1 = t1;
        test2 = t2;
        test3 = t3;
    }
   
    public void settest1(double mark1){
        test1=mark1;        
    }
    
    public double gettest1(){
        return test1;
    }
    
    public void settest2(double mark2){
        test2=mark2;
    }
    
    public double gettest2(){
        return test2;
    }
    
    public void settest3(double mark3){
        test3=mark3;
    }
    
    public double gettest3(){
        return test3;
    }
    
    public double getAverage(){
        return (test1 + test2 + test3) / 3;
    }
    
    public char getLettergrade(){
        if (getAverage()<60)
            return 'F';
        else if(getAverage()<70)
            return 'D';
        else if(getAverage()<80)
            return 'C';
        else if(getAverage()<90)
            return 'B';
        else 
            return 'A';        
    }
}
