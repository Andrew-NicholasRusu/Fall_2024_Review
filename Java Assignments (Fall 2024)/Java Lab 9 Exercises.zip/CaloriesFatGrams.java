/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calories.fatgramsdemo;

public class CaloriesFatGrams {
    private double calories;
    private double fatgrams; 

public CaloriesFatGrams(double cal, double fatg){
    calories = cal;
    fatgrams = fatg;
}

public void setcalories(double cal){
    calories = cal;
}

public double getcalories(){
    return calories;
}

public void setfatgrams(double fatg){
    fatgrams = fatg;
}

public double getfatgrams(){
    return fatgrams;
}

public double getcaloriesfromfat(){
    return fatgrams * 9;
}

public double getPercentage(){
    this.getcaloriesfromfat();
    return getcaloriesfromfat() / calories;
}

}
