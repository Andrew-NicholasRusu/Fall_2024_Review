/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bank;

public class Bank {
    
    private double amountofmoney;
    private double numberofchecks;
    
    public Bank(double AOM, double NOC){
        amountofmoney = AOM;
        numberofchecks = NOC;
    }
    
    public double getchargepermonth(){
        
        
        return amountofmoney;
    }
    
     public void setnumberofchecks(double NOC){
        numberofchecks = NOC;
    }
    
    public double getnumberofchecks(){
        return numberofchecks;
    }
    
    public double getCheckPayment(){
        double AmountOwed = 0;
        double nbChecks = getnumberofchecks();
        if (nbChecks<20)
            AmountOwed = 0.10 * nbChecks;
        else if (nbChecks<40)
            AmountOwed = 0.08 * nbChecks;
        else if (nbChecks<60)
            AmountOwed = 0.06 * nbChecks;
        else if (nbChecks>60)
        AmountOwed = 0.04 * nbChecks;
        if (amountofmoney <400)
            AmountOwed += 15;
        
        return AmountOwed;
            
    }
       
}
    

