/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testscores.lab.pkg9;



public class TestScoresLab9Demo {
    
public static void main(String[] args){
    
    TestScoresLab9 student1=new TestScoresLab9(96.00,79.00,90.00);
    TestScoresLab9 student2=new TestScoresLab9(96.00,98.00,95.00);  
    TestScoresLab9 student3=new TestScoresLab9(60.00,65.00,58.00);    
    
    System.out.println("Letter Grade for Student 1 = "+ student1.getLettergrade());
    System.out.println("Average = " + student1.getAverage());
    System.out.println("");
    
    System.out.println("Letter Grade for Student 2 = "+ student2.getLettergrade());
    System.out.println("Average = "+student2.getAverage());
    System.out.println("");
    
    System.out.println("Letter Grade for Student 3 = "+ student3.getLettergrade());
    System.out.println("Average = "+student3.getAverage());
    System.out.println("");
}
    
}
