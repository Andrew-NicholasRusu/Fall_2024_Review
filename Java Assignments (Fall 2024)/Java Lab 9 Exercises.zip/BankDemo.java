/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank;
import java.util.Scanner;

public class BankDemo {

    public static void main(String[] args){
        Scanner keyboard=new Scanner(System.in);
        double amount,checks;
        
        System.out.println("Please enter an amount of money:");
        amount = keyboard.nextDouble();
        
        System.out.println("Please enter an amount of checks given:");
        checks = keyboard.nextDouble();
        
        Bank wallet1 = new Bank( amount, checks);
        System.out.println("Total money owed =" +wallet1.getCheckPayment());

    }
}
