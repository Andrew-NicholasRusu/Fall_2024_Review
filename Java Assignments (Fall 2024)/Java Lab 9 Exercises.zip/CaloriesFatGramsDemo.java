/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calories.fatgramsdemo;
import java.util.Scanner; 

public class CaloriesFatGramsDemo {
public static void main(String[] args) {
double calories, fatgrams;   
    
    Scanner keyboard=new Scanner(System.in);
    
    System.out.println("Please enter an amount of calories in a food item:");
    calories = keyboard.nextDouble();
    
    System.out.println("Please enter an amount of fat grams in a food item:");
    fatgrams = keyboard.nextDouble();
    
    CaloriesFatGrams product1 = new CaloriesFatGrams(calories, fatgrams);
    
    double Percentage = product1.getPercentage();
    System.out.println(Percentage);
    if (product1.getcalories() < product1.getcaloriesfromfat())
        System.out.println("ERROR");
    else {        
        if (product1.getcalories() > product1.getcaloriesfromfat())
             System.out.println("THE FOOD IS LOW IN FAT");
        else
            
            System.out.println("THE FOOD IS HIGH IN FAT");
    
    
    }
   
   }
}
