/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package males.and.females.pkg2.of.lab.pkg2;

import java.util.Scanner;

public class MalesAndFemales2OfLab2 {
    public static void main(String[] args) {
        double male,female,malepercentage,femalepercentage,students;
        Scanner keyboard=new Scanner(System.in);
        System.out.println("How many males are in this class?");
        male=keyboard.nextDouble();
        System.out.println("How many females are in this class?");
        female=keyboard.nextDouble();
        System.out.println("This means that there is a total of");
        students=male+female;
        System.out.println("students" +students);
        malepercentage=male/students;
        System.out.println("malepercentage" +malepercentage);
        femalepercentage=female/students;
        System.out.println("femalepercentage" +femalepercentage);
        
    }
    
}
