/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cookies;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class Cookies {

    public static void main(String[] args) {
    double Cookies,Calories, Servings;
    Scanner keyboard=new Scanner(System.in);
    System.out.println("How many cookies did you eat?");
    Cookies=keyboard.nextDouble();
    System.out.println("How many calories did you consume?");
    Calories=75*Cookies;
    System.out.println("Calories" +Calories);
  }
    
}
