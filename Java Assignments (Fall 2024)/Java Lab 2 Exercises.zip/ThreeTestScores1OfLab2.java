/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package three.test.scores.pkg1.of.lab.pkg2;

import java.util.Scanner;

public class ThreeTestScores1OfLab2 {
    public static void main(String[] args) {
        double firsttest, secondtest, thirdtest, average;
        Scanner keyboard=new Scanner(System.in);     
       
        System.out.println("Enter the mark of the first test:");
        firsttest=keyboard.nextDouble();
        System.out.println("Enter the mark of the second test:");
        secondtest=keyboard.nextDouble();
        System.out.println("Enter the mark of the third test:");
        thirdtest=keyboard.nextDouble();
        System.out.println("Calculate the average");
        average=(firsttest+secondtest+thirdtest)/3;
        System.out.println("average: "+ average);
    }
    
}
