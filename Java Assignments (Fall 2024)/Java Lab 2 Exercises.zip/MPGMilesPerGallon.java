/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mpg.miles.per.gallon;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class MPGMilesPerGallon {
    public static void main(String[] args) {
        Scanner keyboard=new Scanner(System.in);
        double Milesdriven, Gallonsofgas,Milespergallon;
        System.out.println("How many miles did you drove?");
        Milesdriven=keyboard.nextDouble();
        System.out.println("How many gallons of gas did you use?");
        Gallonsofgas=keyboard.nextDouble();
        Milespergallon=Milesdriven/Gallonsofgas;
        System.out.println("Milespergallon" +Milespergallon);
    }
    
}
